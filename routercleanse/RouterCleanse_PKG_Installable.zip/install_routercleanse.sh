#!/bin/bash

echo "Installing RouterCleanse to /Applications/RouterCleanse..."
INSTALL_DIR="/Applications/RouterCleanse"
mkdir -p "$INSTALL_DIR"

cp "$PWD/RouterCleanse.command" "$INSTALL_DIR/RouterCleanse.command"
chmod +x "$INSTALL_DIR/RouterCleanse.command"

echo "Installation complete. You can run it from:"
echo "$INSTALL_DIR/RouterCleanse.command"
