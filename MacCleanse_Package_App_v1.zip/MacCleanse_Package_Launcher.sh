#!/bin/bash

APPDIR="$HOME/Desktop/maccleanse_package_logs"
mkdir -p "$APPDIR"

CHOICE=$(osascript -e 'button returned of (display dialog "Welcome to MacCleanse Package.\nChoose what to scan:" buttons {"Cancel", "Scan Router", "Scan Mac"} default button "Scan Mac")')

if [[ "$CHOICE" == "Scan Mac" ]]; then
    /Applications/MacCleanse/MacCleanse.command
elif [[ "$CHOICE" == "Scan Router" ]]; then
    /Applications/RouterCleanse/RouterCleanse.command
else
    echo "Cancelled"
fi
